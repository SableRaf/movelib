================================================================
  PLAYSTATION MOVE BLUETOOTH PAIRING UTILITY - v. 0.4.5 (Beta)
================================================================

by Douglas Wilson (www.doougle.net)

Last modified: 2012-12-19
	

------------------------------------------
  INTRODUCTION
------------------------------------------

This Pairing Utility is an open-source C# application that pairs
PlayStation Move controllers by Bluetooth to your computer.

It was built using Unity (http://unity3d.com) and is licensed under 
the GNU Lesser General Public License (v2.1 or later). 
It is still under development.

The full source code and Unity project are available as part of our
UniMove project: http://www.cphgc.org/unimove


--------------------------------
  SYSTEM REQUIREMENTS
--------------------------------

The Pairing Utility runs on Mac OSX 10.5, 10.6, 10.7, and 10.8.
	(If using 10.5, use the alternate "legacy" build)

The Utility requires a Bluetooth connection and one or
more PlayStation Move controllers. You'll also need a mini-USB
cable for the initial connection (once the controller is 
paired, you'll be able to unplug it and use it wirelessly).


--------------------------------
  INSTALLATION & HOW TO USE
--------------------------------

There is no "installation" per se. Just double click the 
"Pairing Utility" application executable. 

Follow the directions in the application.

On OSX 10.5, use the alternate "legacy" build.

On OSX 10.7 and 10.8, the utility will prompt you for 
your user password. This is because we need permission to
write the controller's address to the com.apple.Bluetooth.plist 
file in /Library/Preferences.

On OSX 10.7, you'll probably need to pair each controller *twice* -
make sure to read the directions as detailed in the application!

If the pairing process somehow fails, try:

1. You may need to restart your computer (especially if you're 
having trouble turning Bluetooth back on).

2. Try getting a fresh copy of your Bluetooth plist file. To do so, 
turn off Bluetooth, then delete the the com.apple.Bluetooth.plist file 
in the /Library/Preferences folder (Note: NOT the /Library/Preferences 
directory located in your individual user folder). The file will be 
regenerated automatically when you turn Bluetooth on again.

The process of "pairing" writes the Bluetooth address of your 
computer (or console) into the controller's memory. This means 
that you won't have to re-pair the controller, even if you restart 
your computer. HOWEVER, if you pair the controller to a new computer 
or to a Playstation 3, you will have to re-pair. 

And remember to turn on Bluetooth on your computer BEFORE 
starting the application!


--------------------------------
  CREDITS & TECHNOLOGY
--------------------------------

Design and Programming by Douglas Wilson (www.doougle.net)

Sound and music by and Nicklas "Nifflas" Nygren (nifflas.ni2.se)
The tune comes from the B.U.T.T.O.N. soundtrack:
http://sites.fastspring.com/copenhagengameproductions/product/buttonep

The Pairing Utility was developed in C# and Unity Pro (unity3d.com).

For more info, see our UniMove project page:
http://www.cphgc.org/unimove

(Note: Doug has not yet released the source code to this 0.4.5 version,
but hopes to soon, after a first round of user testing)


This application uses hidapi by Alan Ott:

  Copyright (c) 2010, Alan Ott, Signal 11 Software
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions are met:

    * Redistributions of source code must retain the above copyright notice,
      this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in the
      documentation and/or other materials provided with the distribution.
    * Neither the name of Signal 11 Software nor the names of its
      contributors may be used to endorse or promote products derived from
      this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
  POSSIBILITY OF SUCH DAMAGE.

The source code of hidapi can be obtained from:

  http://www.signal11.us/oss/hidapi/


This application also uses PS Move API by Thomas Perl:

  Copyright (c) 2012 Thomas Perl <m@thp.io>
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions are met:

   1. Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.

   2. Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in the
      documentation and/or other materials provided with the distribution.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
  POSSIBILITY OF SUCH DAMAGE.

The source code of PS Move API can be obtained from:

  http://thp.io/2010/psmove/


--------------------------------
  THANKS!
--------------------------------

Special thanks to Patrick Jarnfelt, Thomas Perl, Christoffer Holmg�rd.


--------------------------------
  CONTACT
--------------------------------

Email: contact@doougle.net
Twitter: @doougle
Web: www.doougle.net


--------------------------------
  VERSION HISTORY
--------------------------------

 0.1.0 (alpha) - 2011-05-30
----------------------------
Pre-alpha debut. Thanks to Brandon Boyer for testing!


 0.2.0 (alpha) - 2011-06-01
----------------------------
-- Re-wrote the directions
-- The application now loops, so you can pair multiple times 
without having to restart


 0.2.1 (alpha) - 2011-06-14
----------------------------
-- Finally built from proper version of Unity Pro


 0.3.0 (beta) - 2011-07-20
----------------------------
-- Public release along w/ our UniMove plugin!
-- Upgraded from alpha to beta status
-- Re-organized code to make it (somewhat) cleaner


 0.4.5 (beta) - 2012-12-19
----------------------------
-- New update for the Sportsfriends Kickstarter alpha backers
-- Updated .bundle file w/ Thomas' new code - should work on 10.8 now!
-- On 10.7 and 10.8, uses Thomas' workaround to manually
write the controller address to the Bluetooth plist file
-- On 10.7, special messaging to step users through the process
-- Other word/flow tweaks
-- Added a second "legacy" build for OS X 10.5
   (requires a different .bundle file)
