#ifndef PSMOVE_LINUXSUPPORT_H
#define PSMOVE_LINUXSUPPORT_H

#include "psmove.h"

int
linux_bluez_register_psmove(char *addr, char *host);

#endif
