package movelib.library;

/** Hold data about all the controller (orientation, position, sensor values)
 *  Used to get all the values at once in MoveManager.getData()
 *
 */

public class MoveData {

}
