package MoveLib.library;

public interface MoveConstants {
	
	// Execution modes
	static public final int QUIET   = 0;
	static public final int VERBOSE = 1;
	
	
}
